using Model.BL;
using Model.DAL;
using Model.Domain;
using Ninject;
using Ninject.Modules;
using Presenter;
using Shared;

namespace WinFormsApp6
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            IKernel ninjectKernel = new StandardKernel(new SimpleConfigModule());
            MainPresenter presenter = ninjectKernel.Get<MainPresenter>();


            //Application.Run(new Form1());
        }
    }

    class SimpleConfigModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IRepository<Employee>>().To<FakeRepository<Employee>>().InSingletonScope();
            Bind<IMainView>().To<Form1>().InSingletonScope();
            Bind<IMainModel>().To<MainModel>().InSingletonScope();
        }
    }
}